# Band decoder for Arduino

More on [web page](https://remoteqth.com/arduino-band-decoder.php)

![Hardware](https://remoteqth.com/img/slide-bd-03.png)
